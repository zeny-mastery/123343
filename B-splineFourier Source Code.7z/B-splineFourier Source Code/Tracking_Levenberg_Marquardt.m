function [grid_coor_ref] = Tracking_Levenberg_Marquardt(Coeffs,init_coordinate,period,t)
%% given a random point at time t and BSF coefficients, find G (grid_coor_ref) that returns the same coordinate at time t.
%  Input:
%   -Coeffs BSF coefficients
%   -init_coordinate the initial coordinate of descent, taken as the coordinate of the point at time t mapped to grid coordinate (G)
%   -period period of Fourier functions
%   -t time at which the point is taken
%   Output:
%   -grid_coor_ref the grid coordinate location at the reference frame, updated at every iteration
%   Dependencies:
%   -basic_cubic_splines
%   -grad_cubic_splines
%%
N_plus_1=(size(Coeffs,4)+1)/2;
exceed=0;
grid_coor_ref=reshape(init_coordinate,1,1,1,3);
motion=[0 0 0];
prev_motion=motion;
lambda_upper=1;
lambda_init=0.001;
lambda_lower=0.00001;
lambda=lambda_init;
err=100;
prev_err=err+1;
ave_err=20;
ave_err_=[];
beta=0.8;
reset=0;
lambda_exp=10;
counter=0;
while (err>0.000001)
    if counter >=10000
        lambda
        break;
    end
    counter=counter+1;
    if((err<prev_err || reset || counter==0))
        lambda=lambda/lambda_exp;
        ave_err=ave_err/2+err/2;
       if((abs((ave_err-err)/ave_err)<0.4)) % randomise starting point if stuck at local minima, plateau or oscillation
          grid_coor_ref=reshape(init_coordinate+(rand(1,3)*2-1)*2,1,1,1,3);
          grid_coor_ref(1)=min(max(1,grid_coor_ref(1)),size(Coeffs,1)*1);
          grid_coor_ref(2)=min(max(1,grid_coor_ref(2)),size(Coeffs,2)*1);
          grid_coor_ref(3)=min(max(1,grid_coor_ref(3)),size(Coeffs,3)*1);
          lambda=lambda_init;
          err=100;
          prev_err=err+1;
          ave_err=20;
       end
        dim1=size(Coeffs,1);
        dim2=size(Coeffs,2);
        dim3=size(Coeffs,3);
        
        if(grid_coor_ref(1)>=((dim1-4)-0.0001)||grid_coor_ref(2)>=((dim2-4)-0.0001)||grid_coor_ref(3)>=((dim3-4)-0.0001)||grid_coor_ref(1)<=(0+0.0001)||grid_coor_ref(2)<=(0+0.0001)||grid_coor_ref(3)<=(0+0.0001))
        exceed=1
        end    
        prev_err=err;
        
         if(reset) % reset=1 if the previous descent increased error or cost instead of decreasing it. In such case, we allow the cost to climb, in hope to escape from local minima
        reset=0;
        lambda=lambda_init;%In such case, the descent speed (lambda) were reset/slowed down to accomodate a the curvature of this new minima
         end
         
        %% cap coordinate to within the grid (which is dependent on image size)
        grid_coor_ref(1)=max(0,grid_coor_ref(1));
        compare=(dim1-4);
        grid_coor_ref(1)=min(grid_coor_ref(1),compare);
        grid_coor_ref(2)=max(0,grid_coor_ref(2));
        compare=(dim2-4);
        grid_coor_ref(2)=min(grid_coor_ref(2),compare);
        grid_coor_ref(3)=max(0,grid_coor_ref(3));
        compare=(dim3-4);
        grid_coor_ref(3)=min(grid_coor_ref(3),compare);
         
        prev_motion=motion;
        if(lambda<lambda_lower)lambda=lambda_lower;end
        
      %% Finding the coordinate at time t given the grid_coor_ref (forward propagation)
        u=grid_coor_ref-floor(grid_coor_ref);
        v=floor(grid_coor_ref)-1;

        ex=0;
        wai=0;
        zet=0;



        for term=1:N_plus_1
        u_term_sin=0;
        v_term_sin=0;
        w_term_sin=0;
        u_term_cos=0;
        v_term_cos=0;
        w_term_cos=0;
        for l=0:3
            for m=0:3
                for o=0:3
                   mul=basic_cubic_splines(u(:,:,:,1),l).*basic_cubic_splines(u(:,:,:,2),m).*basic_cubic_splines(u(:,:,:,3),o);
                   if(term~=1)

                   u_term_sin=u_term_sin+mul.*Coeffs(v(1)+l+2,v(2)+m+2,v(3)+o+2,term+N_plus_1-1,1);
                   v_term_sin=v_term_sin+mul.*Coeffs(v(1)+l+2,v(2)+m+2,v(3)+o+2,term+N_plus_1-1,2);
                   w_term_sin=w_term_sin+mul.*Coeffs(v(1)+l+2,v(2)+m+2,v(3)+o+2,term+N_plus_1-1,3);
                   
                   end
                              
                   u_term_cos=u_term_cos+mul.*Coeffs(v(1)+l+2,v(2)+m+2,v(3)+o+2,term,1);
                   v_term_cos=v_term_cos+mul.*Coeffs(v(1)+l+2,v(2)+m+2,v(3)+o+2,term,2);
                   w_term_cos=w_term_cos+mul.*Coeffs(v(1)+l+2,v(2)+m+2,v(3)+o+2,term,3);
              end
            end
        end



        ex=ex+u_term_sin*(sin(2*pi*(term-1)*t/period));
        ex=ex+u_term_cos*(cos(2*pi*(term-1)*t/period));
        wai=wai+v_term_sin*(sin(2*pi*(term-1)*t/period));
        wai=wai+v_term_cos*(cos(2*pi*(term-1)*t/period));
        zet=zet+w_term_sin*(sin(2*pi*(term-1)*t/period));
        zet=zet+w_term_cos*(cos(2*pi*(term-1)*t/period));
        end
        ex=ex+(grid_coor_ref(1));% add the grid_coor_ref since the value of grid_coor_ref in tref= value of 0th Fourier term
        wai=wai+(grid_coor_ref(2));
        zet=zet+(grid_coor_ref(3));
        
        %%Finding the error in estimation and descent direction (back propagation)
        %Here x is the input (G in manuscript) ,y is the output (X_BSF in manuscript,equation 2)
        dedy=([ex wai zet]-init_coordinate); % dedy=dif in manuscript, dedy stands for the differential of the error w.r.t. output

        err=norm(dedy)/2;%err or e is the sum square error (Cost in the manuscript)
        dydx=zeros(3);
        %calculating del(dif) -> dydx

        for eix=1:3
            dy1dx=0;
            dy2dx=0;
            dy3dx=0;
            u_base_store=0;
            v_base_store=0;
            w_base_store=0;
            for term=1:N_plus_1
            u_term_sin=0;
            v_term_sin=0;
            w_term_sin=0;
            u_term_cos=0;
            v_term_cos=0;
            w_term_cos=0;
            for l=0:3
                for m=0:3
                    for o=0:3
                        switch eix
                            case 1
                                mul=grad_cubic_splines(u(:,:,:,1),l).*basic_cubic_splines(u(:,:,:,2),m).*basic_cubic_splines(u(:,:,:,3),o);
                            case 2
                                mul=basic_cubic_splines(u(:,:,:,1),l).*grad_cubic_splines(u(:,:,:,2),m).*basic_cubic_splines(u(:,:,:,3),o);
                            case 3
                                mul=basic_cubic_splines(u(:,:,:,1),l).*basic_cubic_splines(u(:,:,:,2),m).*grad_cubic_splines(u(:,:,:,3),o);
                        end
                        if(term~=1)
                   u_term_sin=u_term_sin+mul.*Coeffs(v(1)+l+2,v(2)+m+2,v(3)+o+2,term+N_plus_1-1,1);
                   v_term_sin=v_term_sin+mul.*Coeffs(v(1)+l+2,v(2)+m+2,v(3)+o+2,term+N_plus_1-1,2);
                   w_term_sin=w_term_sin+mul.*Coeffs(v(1)+l+2,v(2)+m+2,v(3)+o+2,term+N_plus_1-1,3);
                        end
                   u_term_cos=u_term_cos+mul.*Coeffs(v(1)+l+2,v(2)+m+2,v(3)+o+2,term,1);
                   v_term_cos=v_term_cos+mul.*Coeffs(v(1)+l+2,v(2)+m+2,v(3)+o+2,term,2);
                   w_term_cos=w_term_cos+mul.*Coeffs(v(1)+l+2,v(2)+m+2,v(3)+o+2,term,3);  
                    end
                end
            end
            dy1dx=dy1dx+u_term_sin*(sin(2*pi*(term-1)*t/period));
            dy1dx=dy1dx+u_term_cos*(cos(2*pi*(term-1)*t/period));
            dy2dx=dy2dx+v_term_sin*(sin(2*pi*(term-1)*t/period));
            dy2dx=dy2dx+v_term_cos*(cos(2*pi*(term-1)*t/period));
            dy3dx=dy3dx+w_term_sin*(sin(2*pi*(term-1)*t/period));
            dy3dx=dy3dx+w_term_cos*(cos(2*pi*(term-1)*t/period));


             
            end
            dydx(:,eix)=[dy1dx;dy2dx;dy3dx];
        end 
        dydx=dydx+diag([1 1 1]);
        %% obtaining new descent direction
        dedx=dedy*dydx;
        H=dydx'*dydx;
        motion=inv(H+lambda*diag(diag(H)))*dedx';
        grid_coor_ref=grid_coor_ref-reshape(motion,1,1,1,3)*beta-(1-beta)*reshape(prev_motion,1,1,1,3);
    else
        %% else part, when the descent increased the error instead of decreased it
       grid_coor_ref=grid_coor_ref+reshape(motion,1,1,1,3)*beta+(1-beta)*reshape(prev_motion,1,1,1,3);
       lambda=lambda*lambda_exp;
       if(lambda>lambda_upper )
          lambda=lambda_upper;
          reset=1;
       end
       %% descent direction dedx did not change, but the lambda changes therefore the magnitude\descent speed gets reduced
       motion=inv(H+lambda*diag(diag(H)))*dedx';
       grid_coor_ref=grid_coor_ref-reshape(motion,1,1,1,3)*beta-(1-beta)*reshape(prev_motion,1,1,1,3);

        if(grid_coor_ref(1)>=((dim1-4)-0.0001)||grid_coor_ref(2)>=((dim2-4)-0.0001)||grid_coor_ref(3)>=((dim3-4)-0.0001)||grid_coor_ref(1)<=(0+0.0001)||grid_coor_ref(2)<=(0+0.0001)||grid_coor_ref(3)<=(0+0.0001))
        exceed=1;
        end
        grid_coor_ref(1)=max(0,grid_coor_ref(1));
        compare=(dim1-4);
        grid_coor_ref(1)=min(grid_coor_ref(1),compare);
        grid_coor_ref(2)=max(0,grid_coor_ref(2));
        compare=(dim2-4);
        grid_coor_ref(2)=min(grid_coor_ref(2),compare);
        grid_coor_ref(3)=max(0,grid_coor_ref(3));
        compare=(dim3-4);
        grid_coor_ref(3)=min(grid_coor_ref(3),compare);
        
        %% forward propagation
        u=grid_coor_ref-floor(grid_coor_ref);
        v=floor(grid_coor_ref)-1;
        ex=0;
        wai=0;
        zet=0;
        for term=1:N_plus_1
        u_term_sin=0;
        v_term_sin=0;
        w_term_sin=0;
        u_term_cos=0;
        v_term_cos=0;
        w_term_cos=0;
        for l=0:3
            for m=0:3
                for o=0:3
                   mul=basic_cubic_splines(u(:,:,:,1),l).*basic_cubic_splines(u(:,:,:,2),m).*basic_cubic_splines(u(:,:,:,3),o);
                   if(term~=1)
                   u_term_sin=u_term_sin+mul.*Coeffs(v(1)+l+2,v(2)+m+2,v(3)+o+2,term+N_plus_1-1,1);
                   v_term_sin=v_term_sin+mul.*Coeffs(v(1)+l+2,v(2)+m+2,v(3)+o+2,term+N_plus_1-1,2);
                   w_term_sin=w_term_sin+mul.*Coeffs(v(1)+l+2,v(2)+m+2,v(3)+o+2,term+N_plus_1-1,3);
                   
                   u_term_cos=u_term_cos+mul.*Coeffs(v(1)+l+2,v(2)+m+2,v(3)+o+2,term,1);
                   v_term_cos=v_term_cos+mul.*Coeffs(v(1)+l+2,v(2)+m+2,v(3)+o+2,term,2);
                   w_term_cos=w_term_cos+mul.*Coeffs(v(1)+l+2,v(2)+m+2,v(3)+o+2,term,3); 
                   end
              end
            end
        end
        ex=ex+u_term_sin*(sin(2*pi*(term-1)*t/period));
        ex=ex+u_term_cos*(cos(2*pi*(term-1)*t/period));
        wai=wai+v_term_sin*(sin(2*pi*(term-1)*t/period));
        wai=wai+v_term_cos*(cos(2*pi*(term-1)*t/period));
        zet=zet+w_term_sin*(sin(2*pi*(term-1)*t/period));
        zet=zet+w_term_cos*(cos(2*pi*(term-1)*t/period));
        end
        ex=ex+(grid_coor_ref(1));
        wai=wai+(grid_coor_ref(2));
        zet=zet+(grid_coor_ref(3));

        dedy=([ex wai zet]-init_coordinate);

        err=norm(dedy)/2;

    end
end
if (counter==10000)
    err
    init_coordinate
    grid_coor_ref=init_coordinate;
end

end


