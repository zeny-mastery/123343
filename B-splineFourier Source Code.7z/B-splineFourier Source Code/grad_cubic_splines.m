function out=grad_cubic_splines(t,k)
switch k
    case 0
        out=-(1-t).^2/2;
    case 1
        out=(3*t.^2-4*t)/2;
    case 2
        out=(-3*t.^2+2*t+1)/2;
    case 3
        out=t.^2/2;
    otherwise disp('keep to 3rd order, not configured for higher order')
        out=0;
end
end