'''
File: __init__.py
Description: load all class for medImgProc
             Contains externally usable class
History:
    Date    Programmer SAR# - Description
    ---------- ---------- ----------------------------
  Author: w.x.chan@gmail.com         12JAN2018           - Created

Requirements:
    numpy.py
    matplotlib.py
    imageio.py

Known Bug:
    HSV color format not supported
All rights reserved.
'''
import numpy as np
import matplotlib.pyplot as plt
import matplotlib
from matplotlib.widgets import Slider
matplotlib.rc('text', usetex=True)
'''
variables
'''
STD_INSTRUCTIONS='Press Enter to save and exit, Esc to exit\n '
'''
Internal Use functions
'''
def getLastTwoDimArray(imageArray,dimLoad):
    outputArray=np.copy(imageArray)
    if len(outputArray.shape)>2:
        outputArray=getLastTwoDimArray(outputArray[dimLoad[0]],dimLoad[1:])
    return outputArray
def getFramePts(pts,dimLoad):
    newPts=np.copy(pts)
    for n in range(len(dimLoad)-2):
        if len(newPts)!=0:
            filterFrame=(newPts[:,n]==dimLoad[n])
            newPts=newPts[filterFrame,:]
        else:
            break
    return newPts
def dimToTitle(dimension,showIndex):
    titleOutput=''
    for n in range(len(dimension)):
        titleOutput+=dimension[n]+':'+str(showIndex[n])
        if n==0:
            titleOutput+=r'$\leftrightarrow$ \hspace{1cm} '
        else:
            titleOutput+=r'$\updownarrow$'
    #titleOutput+='\n '+r'$\leftarrow$ $\rightarrow$ \hspace{1cm} $\uparrow$ $\downarrow$'
    
    return titleOutput

'''
Main GUI class
'''
class image2DGUI:
    def __init__(self,imageClass,addInstruct='',disable=[],initPointList=None,showNow=True):
        self.title=None
        self.addInstruct=STD_INSTRUCTIONS
        if addInstruct!='':
            self.addInstruct+=addInstruct+'\n '
        if type(imageClass)==str:
            self.image=medImgProc.imread(imageClass)
        self.image=imageClass.clone()
        self.fig=plt.figure(1)
        self.showIndex=[]
        for n in self.image.data.shape:
            self.showIndex.append(0)
        self.disable=disable
        self.connectionID=[]
        if 'click' not in self.disable:
            self.connectionID.append(self.fig.canvas.mpl_connect('button_press_event', self.onclick))
        self.connectionID.append(self.fig.canvas.mpl_connect('key_press_event',self.onKeypress))   
        self.enter=False
        '''
        Return parameters
        '''
        if initPointList is None:
            self.points=np.empty((0,len(self.image.dim)))
        else:
            '''sanitize to show'''
            initPointList=np.copy(initPointList)
            for n in range(len(initPointList)):
                for m in range(len(initPointList[n])-2):
                    initPointList[n,m]=np.round(initPointList[n,m])
            self.points=initPointList
        self.axslide=[]
        self.sSlide=[]
        self.loadImageFrame()

        if showNow:
            plt.show()
    def sliderUpdate(self,val):
        for n in range(len(self.showIndex)-2):
            self.showIndex[n]=int(self.sSlide[n].val)
        self.showNewFrame()
    def onclick(self,event):
        if not(event.dblclick) and event.button==1 and event.inaxes==self.ax:
            newPt=np.array([*self.showIndex[:-2],event.ydata,event.xdata])
            self.points=np.vstack((self.points,newPt))
        #print('%s click: button=%d, x=%d, y=%d, xdata=%f, ydata=%f' %('double' if event.dblclick else 'single', event.button,event.x, event.y, event.xdata, event.ydata))
        self.showNewPoints()
    def onKeypress(self,event):
        if event.key == 'escape':#return values and quit
            for connection in self.connectionID:
                self.fig.canvas.mpl_disconnect(connection)
            plt.close(event.canvas.figure)
        elif event.key == 'enter':
            self.enter=True
            for connection in self.connectionID:
                self.fig.canvas.mpl_disconnect(connection)
            plt.close(event.canvas.figure)
        elif event.key=='up':
            self.switchFrame(-3,1)
        elif event.key=='down':
            self.switchFrame(-3,-1)
        elif event.key=='right':
            self.switchFrame(-4,1)
        elif event.key=='left':
            self.switchFrame(-4,-1)
        elif event.key=='ctrl+z':
            self.removeLastPoint()
        elif event.key in self.image.dim:
            self.swapFrame(event.key)
        else:
            print(event.key)

    def switchFrame(self,index,val=1):
        if len(self.showIndex)>=(-index):
            self.showIndex[index]+=val
            if self.showIndex[index]>(self.image.data.shape[index]-1):
                self.showIndex[index]=0
            elif self.showIndex[index]<0:
                self.showIndex[index]=self.image.data.shape[index]-1
            self.sSlide[len(self.showIndex)+index].set_val(self.showIndex[index])
        self.showNewFrame()
    def swapFrame(self,axis):
        if 'swap' not in self.disable:
            transposeIndex=self.image.rearrangeDim([axis],arrangeFront=False)
            newShowIndex=[]
            for n in range(len(transposeIndex)):
                newShowIndex.append(self.showIndex[transposeIndex[n]])
            self.showIndex=newShowIndex
            self.points=self.points[:,transposeIndex]
            plt.clf()
            self.loadImageFrame()
            self.showNewFrame()
    def showNewFrame(self):
        newShowImage=getLastTwoDimArray(self.image.data,self.showIndex)
        self.main.set_data(newShowImage)
        self.showNewPoints()
        
        
        pp=plt.setp(self.title,text=self.addInstruct+dimToTitle(self.image.dim[:-2],self.showIndex[:-2]))
        self.fig.canvas.draw()
    def showNewPoints(self):
        showpoints=getFramePts(self.points,self.showIndex)
        self.ptplt.set_offsets(showpoints[:,[-1,-2]])
        self.fig.canvas.draw()
        
    def loadImageFrame(self):
        self.ax = self.fig.add_subplot(111)
        self.fig.subplots_adjust(bottom=len(self.showIndex)*0.04)
        showImage=getLastTwoDimArray(self.image.data,self.showIndex)
        self.main=self.ax.imshow(showImage,cmap=matplotlib.cm.gray, vmin=0, vmax=255)

        showpoints=getFramePts(self.points,self.showIndex)
        self.ptplt=self.ax.scatter(showpoints[:,-1],showpoints[:,-2],color='r',marker='x')

        self.title=plt.title(self.addInstruct+dimToTitle(self.image.dim[:-2],self.showIndex[:-2]))
        plt.ylabel(self.image.dim[-2])
        plt.xlabel(self.image.dim[-1])

        '''set slider for image control'''
        axcolor = 'lightgoldenrodyellow'
        self.axslide=[]
        self.sSlide=[]
        for n in range(len(self.showIndex)-2):
            self.axslide.append(self.fig.add_axes([0.1, 0.02+n*0.04, 0.65, 0.03], facecolor=axcolor))
            self.sSlide.append(Slider(self.axslide[-1], self.image.dim[n], 0, self.image.data.shape[n]-1, valinit=self.showIndex[n],valfmt="%i"))
            self.sSlide[-1].on_changed(self.sliderUpdate)
        
    def removeLastPoint(self):
        self.points=self.points[:-1,:]
        self.showNewPoints()
    def show(self):
        plt.show()
