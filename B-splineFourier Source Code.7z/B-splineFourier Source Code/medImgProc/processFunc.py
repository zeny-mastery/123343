'''
File: processFunc.py
Description: various function to process image
             
History:
    Date    Programmer SAR# - Description
    ---------- ---------- ----------------------------
  Author: w.x.chan@gmail.com         12JAN2018           - Created

Requirements:
    numpy

All rights reserved.
'''

import numpy as np
import os
import sys
sys.path.insert(0, os.path.dirname(os.path.realpath(__file__)))
import SimpleITK as sitk
import re


'''
t0 and tn-1 ratio
'''
def timestepPoly(n,timeStepNo):
    return float(n-1)*float(timeStepNo-1-n)/((timeStepNo-1)/2.)**2.


'''
Register using SimpleITK and output the bspline coefficient with the appropriate file names
'''
def TmapRegister(image,savePath='',origin=(0.,0.,0.),bgrid=2.,bweight=1.,rms=True,startTime=0,scaleImg=1.):
    image=image.clone()
    for axis in ['x','y','z']:
        if axis in image.dimlen:
            image.dimlen[axis]=image.dimlen[axis]*scaleImg
    if not(savePath):
        savePath=os.path.dirname(os.path.realpath(__file__))
    
    os.makedirs(savePath, exist_ok=True)
    os.makedirs(savePath+'/transform', exist_ok=True)
    spacing=(image.dimlen['x'],image.dimlen['y'],image.dimlen['z'])
    
    parameterMapVector = sitk.VectorOfParameterMap()
    affine=sitk.GetDefaultParameterMap("affine")
    bspline=sitk.GetDefaultParameterMap("bspline")
    bspline['Metric0Weight']=(str(bweight),)
    bspline['FinalGridSpacingInPhysicalUnits']=(str(max(spacing)*bgrid),)
    #bspline["Metric"]=(*bspline["Metric"],"DisplacementMagnitudePenalty")
    if rms:
        bspline["Metric"]=("AdvancedMeanSquares",bspline["Metric"][1])
    #parameterMapVector.append(affine)
    parameterMapVector.append(bspline)
    
    
    '''start'''
    colorVec=False
    if 'RGB' in image.dim:
        colorVec=True

    fixImg=sitk.GetImageFromArray(np.copy(image.data[0]), isVector=colorVec)
    fixImg.SetOrigin(origin)
    fixImg.SetSpacing(spacing)
    sitk.WriteImage(fixImg,savePath+'/t0Img.mha')
    timeList=np.array(range(len(image.data)))*image.dimlen['t']
    np.savetxt(savePath+'/transform/timeList',timeList)
    for n in range(startTime,image.data.shape[0]-1):
        if n!=0:
            print('Registering t',n+1,' wrt t',n)
            elastixImageFilter=sitk.ElastixImageFilter()
            elastixImageFilter.LogToFileOn()
            elastixImageFilter.LogToConsoleOff()
            fixImg=sitk.GetImageFromArray(np.copy(image.data[n]), isVector=colorVec)
            fixImg.SetOrigin(origin)
            fixImg.SetSpacing(spacing)
            movImg=sitk.GetImageFromArray(np.copy(image.data[n+1]), isVector=colorVec)
            movImg.SetOrigin(origin)
            movImg.SetSpacing(spacing)
            elastixImageFilter.SetFixedImage(fixImg)
            elastixImageFilter.SetMovingImage(movImg)
            elastixImageFilter.SetParameterMap(parameterMapVector)
            elastixImageFilter.Execute()
            Tmap=elastixImageFilter.GetTransformParameterMap()
            for m in range(len(Tmap)):
                sitk.WriteParameterFile(Tmap[m],savePath+'/transform/t'+str(n)+'to'+str(n+1)+'_'+str(m)+'.txt')
        
        print('Registering t',n+1,' wrt t',0)
        elastixImageFilter=sitk.ElastixImageFilter()
        elastixImageFilter.LogToFileOn()
        elastixImageFilter.LogToConsoleOff()
        fixImg=sitk.GetImageFromArray(np.copy(image.data[0]), isVector=colorVec)
        fixImg.SetOrigin(origin)
        fixImg.SetSpacing(spacing)
        movImg=sitk.GetImageFromArray(np.copy(image.data[n+1]), isVector=colorVec)
        movImg.SetOrigin(origin)
        movImg.SetSpacing(spacing)
        elastixImageFilter.SetFixedImage(fixImg)
        elastixImageFilter.SetMovingImage(movImg)
        elastixImageFilter.SetParameterMap(parameterMapVector)
        elastixImageFilter.Execute()
        Tmap=elastixImageFilter.GetTransformParameterMap()
        for m in range(len(Tmap)):
            sitk.WriteParameterFile(Tmap[m],savePath+'/transform/t0to'+str(n+1)+'_'+str(m)+'.txt')


