function [BSF] = readBSF(batch_correct_file_loc)
% Read the BSF parameters from a text file
%   Input:
%   -batch_correct_file_loc location of the Bspline Fourier text files
%   Output:
%   -BSF.GridOrigin= origin of the b-spline grid in physical coordinate
%   -BSF.GridSpacing= spacig of the b-spline grid (i.e a,b,c in manuscript)
%   -BSF.GridSize= size of the b-spline grid, its size is different from the size of the coeff due to zero padding of the coeff
%   -BSF.Coeffs= the coefficients of the BSF, it is padded in 3D to be consistent with python implementation, size(BSF.Coeffs)=[BSF.GridSize(1:3)+3 BSF.GridSize(4:end)]
%%

BSF=struct('Coeffs',[],'GridSize',[],'GridSpacing',[],'GridOrigin',[]);
fid = fopen(batch_correct_file_loc,'rt');
teixt=[];
teixt=fgets(fid);
teixt(1:12)=[];
teixt((end-5):end)=[];
BSF.GridOrigin=str2num(teixt);

teixt=[];
teixt=fgets(fid);
teixt(1:10)=[];
teixt(strfind(teixt,')'))=[];
BSF.GridSize=str2num(teixt);

teixt=[];
teixt=fgets(fid);
teixt(1:13)=[];
teixt((end-6):end)=[];
BSF.GridSpacing=str2num(teixt);

fclose(fid);

coeff_colate4=dlmread(batch_correct_file_loc,' ',3);
coeff_colate4=reshape(coeff_colate4, BSF.GridSize);
%scale/trasnform coeff from real coordinate to grid system
coeff_colate4(:, :,:,:,1)=coeff_colate4(:, :,:,:,1)/BSF.GridSpacing(1);
coeff_colate4(:, :,:,:,2)=coeff_colate4(:, :,:,:,2)/BSF.GridSpacing(2);
coeff_colate4(:, :,:,:,3)=coeff_colate4(:, :,:,:,3)/BSF.GridSpacing(3);

% padding with zeros(python count indexing from zero, matlab counts from
% one, so we pad the difference with zeros)
   coeff_colate4=cat(1,coeff_colate4,repmat(zeros(size(coeff_colate4(end,:,:,:,:))),2,1,1,1,1));
   coeff_colate4=cat(2,coeff_colate4,repmat(zeros(size(coeff_colate4(:,end,:,:,:))),1,2,1,1,1));
   coeff_colate4=cat(3,coeff_colate4,repmat(zeros(size(coeff_colate4(:,:,end,:,:))),1,1,2,1,1));
   
   coeff_colate4=cat(1,repmat(zeros(size(coeff_colate4(1,:,:,:,:))),1,1,1,1,1),coeff_colate4);
   coeff_colate4=cat(2,repmat(zeros(size(coeff_colate4(:,1,:,:,:))),1,1,1,1,1),coeff_colate4);
   coeff_colate4=cat(3,repmat(zeros(size(coeff_colate4(:,:,1,:,:))),1,1,1,1,1),coeff_colate4);
BSF.Coeffs=coeff_colate4;
end

