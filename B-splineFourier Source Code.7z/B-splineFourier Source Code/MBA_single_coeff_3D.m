function [ coeff_rep ] = MBA_single_coeff_3D( x,y,z,val,n,h,limits )
% MultiLevelBspline cubic function, coded for 3D object interpolation
% Based on algorithm published by: 
% Lee, Seungyong, George Wolberg, and Sung Yong Shin. "Scattered data interpolation with multilevel B-splines." IEEE transactions on visualization and computer graphics 3.3 (1997): 228-244.
%	Input:
%	-x,y,z the corresponding x y and z coordinate of data to be interpolated
%	-val value to be interpolated
%	-limits range of value of x y z to be interpolated
%	-n number of b-spline seeds
%	-h number of b-spline levels used
%	Output:
%	-coeff_rep Coefficients of b-splines
%	Dependencies:
%	-BA_3D
%	-find_phi_prime
%	-basic_cubic_splines
fitted=zeros(size(x));
u_temp=val;

for k=0:max(h)
    den=[limits(1)/(n(1)*2^(min(k,h(1)))) limits(2)/(n(2)*2^(min(k,h(2)))) limits(3)/(n(3)*2^(min(k,h(3))))];
    coor=cat(4,x,y,z);
    den=repmat(reshape(den,1,1,1,3),size(coor,1),size(coor,2),size(coor,3),1);
    u=(coor./den-floor(coor./den));
    v=floor(coor./den)-1;
    u_temp=val-fitted;
    coeff=BA_3D(x,y,z,u_temp,n.*[2 2 2].^[min(k,h(1)) min(k,h(2)) min(k,h(3))],limits);
    if k==0
        coeff_rep=coeff;
    else
        %convert prev_coeff of prev res to curr res
        phi_prime=zeros(size(coeff));
        phi_prime_colate1=zeros(size(coeff,1),size(prev_coeff,2),size(prev_coeff,3));
        if(k<=h(1))
        for kay=1:(size(prev_coeff,3))
            for jay=1:(size(prev_coeff,2))
               phi_prime_colate1(:,jay,kay)=find_phi_prime(prev_coeff(:,jay,kay));
            end
        end
        else phi_prime_colate1=prev_coeff;
        end 
        
        if(k<=h(2))
        phi_prime_colate2=zeros(size(coeff,1),size(coeff,2),size(prev_coeff,3));
        for kay=1:(size(phi_prime_colate1,3))
            for jay=1:(size(phi_prime_colate1,1))
               phi_prime_colate2(jay,:,kay)=find_phi_prime(phi_prime_colate1(jay,:,kay));
            end
        end
        else phi_prime_colate2=phi_prime_colate1;
        end
        
        if(k<=h(3))
        for kay=1:(size(phi_prime_colate2,2))
            for jay=1:(size(phi_prime_colate2,1))
               phi_prime(jay,kay,:)=find_phi_prime(phi_prime_colate2(jay,kay,:));
            end
        end
        else phi_prime=phi_prime_colate2;
        end
        coeff_rep=coeff+phi_prime;
    end
    fitted=zeros(size(x));
 
    for a=0:3
        for b=0:3
            for c=0:3
                idx=(v(:,:,:,1)+a+2)+ (v(:,:,:,2)+b+2-1)*size(coeff_rep,1) + (v(:,:,:,3)+c+2-1)*size(coeff_rep,2)*size(coeff_rep,1);
        fitted=fitted+basic_cubic_splines(u(:,:,:,1),a).*basic_cubic_splines(u(:,:,:,2),b).*basic_cubic_splines(u(:,:,:,3),c).*coeff_rep(idx);
            end
        end
    end
    prev_coeff=coeff_rep;
    max(max(max(abs((u_temp)))))    
end
den=den(1,1,1,1:3);
end

