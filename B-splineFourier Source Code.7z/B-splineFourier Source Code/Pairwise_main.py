
import numpy as np
import os
#import matplotlib
import sys
#sys.path.insert(0, os.path.dirname(os.path.realpath(__file__)))
import medImgProc
import medImgProc.processFunc as pf
import re

import bfmotionsolver

'''
User Variables
'''
fileScale=200. #file saling property due to the limitation of elastix which stores values as characters, to prevent trucation, all values were scaled by fixed number
savePath=r'C:\Users\yaplab2\Desktop\Sheldon method paper data\NE140' #data case directory
bgrid=10.  #ratio of grid size to largest element spacing
bweight=1. #ratio of objective to regualrization weights used for sitk image registration
vtkPath=savePath+'/3DUS/VTK/VTK{0:02d}.vtk'
vtkelementspacing=[0.658114, 0.667832, 0.580462] #pixel to physical coordinate conversion (x,y,z)

dimension=['z','y','x']
'''
Step 1: Image registration 
'''
changeDim={}
for n in range(3):
    changeDim[dimension[n]]=vtkelementspacing[2-n]*fileScale
changeDim['t']=1.
TFimages=[]
for TF in range(100):
    newImg=medImgProc.imread(vtkPath.format(TF),dimension=dimension)
    if type(newImg.data)==type(None):
        break
    else:
        TFimages.append(newImg)
caseImage=medImgProc.stackImage(TFimages,'t')
caseImage.dimlen=changeDim.copy()
caseImage.save(savePath+'/img')
pf.TmapRegister(caseImage,savePath=savePath+'/RMSw'+str(bweight)+'b'+str(bgrid),origin=(0.,0.,0.),bgrid=bgrid,bweight=bweight,rms=True)
