%% Used to obtain grid coordinate reference given a node location at any time t, for this example, t=0 and the nodes are given by stl files.
% Dependencies (not provided):
% -stlread by Eric Johnson download from:https://www.mathworks.com/matlabcentral/fileexchange/22409-stl-file-reader?focused=5193625&tab=function
% -stlwrite by Sven Holcombe download from:https://www.mathworks.com/matlabcentral/fileexchange/20922-stlwrite-write-ascii-or-binary-stl-files
% Provided:
% -stl_volume
% -Matlab parallel computing toolbox, or change 'parfor' into 'for' to convert to serial run
%  it would take roughly half an hour to complete 10000 vertices stl in serial
% 
period=26;
work_dir='H:\B-splineFourier data\Zebrafish_data\Zebrafish 1\result\bsf';
batch_correct_file_loc= [work_dir '\' 'Shape19x19x19x9_noManual_f4.txt'];
[F,V_all,Normal]=stlread(['H:\B-splineFourier data\Zebrafish_data\Zebrafish 1\result\bsf\Shape19x19x19x9_noManual_f4' '\' 't0.stl']);
stl_original_time=0;
Write_FileLoc=[work_dir '\' 'Shape19x19x19x9_noManual_f4\try'];

%% read the BSF parameters and coefficients
BSF=readBSF(batch_correct_file_loc);
N_plus_1=(BSF.GridSize(4)+1)/2;

%% reading Stl at t0 or any chosen t
mkdir(Write_FileLoc);
stlwrite([Write_FileLoc '/' sprintf('t%d.stl',0)],F,V_all);
V_all=(V_all-repmat(BSF.GridOrigin,size(V_all,1),1))./repmat(BSF.GridSpacing,size(V_all,1),1); % convert vertices to grid_coordinate (G)
[uhnique locations locations2]=unique(V_all,'rows');
grid_coor=reshape(uhnique,size(uhnique,1),1,1,3);
grid_coor_ref=zeros(size(grid_coor));

%% converting all t0 points to tref
fin=size(grid_coor,1);
parfor i= 1:size(grid_coor,1)
    grid_coor_ref(i,:,:,:)=Tracking_Levenberg_Marquardt(BSF.Coeffs,reshape(grid_coor(i,:,:,:),1,3,1,1),period,stl_original_time);
    if (rem(i,10)==0)
        completion=i/fin
    end
end
stlwrite([Write_FileLoc '/tis_ref.stl'],F,(grid_coor_ref(locations2,:).*repmat(BSF.GridSpacing,size(V_all,1),1)+repmat(BSF.GridOrigin,size(V_all,1),1)).*repmat([1 1 1],size(V_all,1),1))
%% Use the tref grid location to track the location at any every time points t
grid_coor_stor=reshape(grid_coor_ref,size(grid_coor_ref,1),3);
vol_stor=[];
for t=0:period
u=grid_coor_ref-floor(grid_coor_ref); % called (o; p; q;) in the manuscript
v=floor(grid_coor_ref)-1; % called (i; j; k;) in the manuscript
ex=0;
wai=0;
zet=0;
for f=1:N_plus_1
u_term_sin=0;
v_term_sin=0;
w_term_sin=0;
u_term_cos=0;
v_term_cos=0;
w_term_cos=0;
for l=0:3
    for m=0:3
        for o=0:3
           mul=basic_cubic_splines(u(:,:,:,1),l).*basic_cubic_splines(u(:,:,:,2),m).*basic_cubic_splines(u(:,:,:,3),o);
           idx=v(:,:,:,1)+l+2+(v(:,:,:,2)+m+1)*size(BSF.Coeffs,1)+(v(:,:,:,3)+o+1)*size(BSF.Coeffs,1)*size(BSF.Coeffs,2);
           if(f~=1)
               u_term_sin=u_term_sin+mul.*BSF.Coeffs(idx+(f+N_plus_1-2)*size(BSF.Coeffs,1)*size(BSF.Coeffs,2)*size(BSF.Coeffs,3));
               v_term_sin=v_term_sin+mul.*BSF.Coeffs(idx+(f+N_plus_1-2)*size(BSF.Coeffs,1)*size(BSF.Coeffs,2)*size(BSF.Coeffs,3)+size(BSF.Coeffs,1)*size(BSF.Coeffs,2)*size(BSF.Coeffs,3)*size(BSF.Coeffs,4));
               w_term_sin=w_term_sin+mul.*BSF.Coeffs(idx+(f+N_plus_1-2)*size(BSF.Coeffs,1)*size(BSF.Coeffs,2)*size(BSF.Coeffs,3)+size(BSF.Coeffs,1)*size(BSF.Coeffs,2)*size(BSF.Coeffs,3)*size(BSF.Coeffs,4)*2);
           end
           u_term_cos=u_term_cos+mul.*BSF.Coeffs(idx+(f-1)*size(BSF.Coeffs,1)*size(BSF.Coeffs,2)*size(BSF.Coeffs,3));
           v_term_cos=v_term_cos+mul.*BSF.Coeffs(idx+(f-1)*size(BSF.Coeffs,1)*size(BSF.Coeffs,2)*size(BSF.Coeffs,3)+size(BSF.Coeffs,1)*size(BSF.Coeffs,2)*size(BSF.Coeffs,3)*size(BSF.Coeffs,4));
           w_term_cos=w_term_cos+mul.*BSF.Coeffs(idx+(f-1)*size(BSF.Coeffs,1)*size(BSF.Coeffs,2)*size(BSF.Coeffs,3)+size(BSF.Coeffs,1)*size(BSF.Coeffs,2)*size(BSF.Coeffs,3)*size(BSF.Coeffs,4)*2);           
      end
    end
end
ex=ex+u_term_sin*(sin(2*pi*(f-1)*t/period));
ex=ex+u_term_cos*(cos(2*pi*(f-1)*t/period));
wai=wai+v_term_sin*(sin(2*pi*(f-1)*t/period));
wai=wai+v_term_cos*(cos(2*pi*(f-1)*t/period));
zet=zet+w_term_sin*(sin(2*pi*(f-1)*t/period));
zet=zet+w_term_cos*(cos(2*pi*(f-1)*t/period));

end

ex=ex+(grid_coor_ref(:,:,:,1)); % add grid coor back, the zeroth Fourier term is stored as the grid_coor_ref since motion averaged reference is used
wai=wai+(grid_coor_ref(:,:,:,2));
zet=zet+(grid_coor_ref(:,:,:,3));
result=cat(2,ex,wai,zet);
vol_stor=[vol_stor stl_volume(F,(result(locations2,:).*repmat(BSF.GridSpacing,size(V_all,1),1)+repmat(BSF.GridOrigin,size(V_all,1),1)).*repmat([1 1 1],size(V_all,1),1))];
stlwrite([Write_FileLoc '/' sprintf('t%d.stl',t)],F,(result(locations2,:).*repmat(BSF.GridSpacing,size(V_all,1),1)+repmat(BSF.GridOrigin,size(V_all,1),1)).*repmat([1 1 1],size(V_all,1),1))

end

figure();
plot(vol_stor);

grad=vol_stor(2:end)-vol_stor(1:end-1);