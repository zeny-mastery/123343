function [] = run_initialisation(reg,TransformFolder,N,b_spline_seed,levels,OutputFileName)
%% run_initialisation Summary of this function goes here
%   Bulk of the initialisation procedure including March Forward, Fourier
%   fit and Multi Level B-spline (MLB)

%% Preparing variables
numSlice=reg.ImgSize(3);
var=reg.Coeffs(:,:,:,:,find((reg.dt)==1)); % get dX_t->t+1
var=reshape(var,reg.GridSize(1),reg.GridSize(2),reg.GridSize(3),reg.GridSize(4),reg.GridSize(5));
var=permute(var,[ 1 2 3 5 4]);
% duplicate padding at the ends of x y and z with its final value twice to make
% use of the whole image
var=cat(1,var,repmat(var(end,:,:,:,:),2,1,1,1,1));
var=cat(2,var,repmat(var(:,end,:,:,:),1,2,1,1,1));
var=cat(3,var,repmat(var(:,:,end,:,:),1,1,2,1,1));
% Do not need duplicate padding at the front of x y and z since the
% origin is negative

var_0=reg.Coeffs(:,:,:,:,find(reg.dt==0)); % get dX_0->t
var_0=reshape(var_0,reg.GridSize(1),reg.GridSize(2),reg.GridSize(3),reg.GridSize(4),reg.GridSize(5));
var_0=permute(var_0,[ 1 2 3 5 4]);
% Duplicate padding at the ends of x y and z with its final value to make
% use of the whole image
var_0=cat(1,var_0,repmat(var_0(end,:,:,:,:),2,1,1,1,1));
var_0=cat(2,var_0,repmat(var_0(:,end,:,:,:),1,2,1,1,1));
var_0=cat(3,var_0,repmat(var_0(:,:,end,:,:),1,1,2,1,1));

%% sampling points
x_lim=[0 reg.ImgSize(1)-1]
y_lim=[0 reg.ImgSize(2)-1];
z_lim=[0 numSlice-1];
x_grid_lim=(x_lim*reg.ImgSpacing(1)-reg.GridOrigin(1))/reg.GridSpacing(1); %in G coordinate
y_grid_lim=(y_lim*reg.ImgSpacing(2)-reg.GridOrigin(2))/reg.GridSpacing(2); %in G coordinate
z_grid_lim=(z_lim*reg.ImgSpacing(3)-reg.GridOrigin(3))/reg.GridSpacing(3); %in G coordinate

[x y, z]=meshgrid(floor(x_grid_lim(1)):(1):ceil(x_grid_lim(2)),floor(y_grid_lim(1)):(1):ceil(y_grid_lim(2)),floor(z_grid_lim(1)):(1):ceil(z_grid_lim(2)));

grid_coor=cat(4,x,y,z);
img_corr=(grid_coor.*repmat(reshape(reg.GridSpacing,1,1,1,3),size(grid_coor,1),size(grid_coor,2),size(grid_coor,3))+repmat(reshape(reg.GridOrigin,1,1,1,3),size(grid_coor,1),size(grid_coor,2),size(grid_coor,3)))./repmat(reshape(reg.ImgSpacing,1,1,1,3),size(grid_coor,1),size(grid_coor,2),size(grid_coor,3));
grid_coor_ori=grid_coor;

%% Forward March
coor_colate=zeros(size(grid_coor,1),size(grid_coor,2),size(grid_coor,3),size(grid_coor,4),reg.GridSize(5));
t=0;
disp("Foward Marching");
for t=0:(reg.GridSize(5)-1)
    t
ratio=(t)*(reg.GridSize(5)-(t))/((reg.GridSize(5)/2)^2);
u_displace=0;
v_displace=0;
w_displace=0;
u_displace_0=0;
v_displace_0=0;
w_displace_0=0;

for l=0:3
    for m=0:3
        for n=0:3
           % eulerian (dX_t->t+1)
           u=grid_coor-floor(grid_coor);
           v=floor(grid_coor)-1;
           idx=v(:,:,:,1)+l+1+(v(:,:,:,2)+m)*size(var_0,1)+(v(:,:,:,3)+n)*size(var_0,1)*size(var_0,2);
           mul=basic_cubic_splines(u(:,:,:,1),l).*basic_cubic_splines(u(:,:,:,2),m).*basic_cubic_splines(u(:,:,:,3),n);
           u_displace=u_displace+mul.*(var(idx+t*size(var,1)*size(var,2)*size(var,3)+0));
           v_displace=v_displace+mul.*(var(idx+t*size(var,1)*size(var,2)*size(var,3)+1*size(var,1)*size(var,2)*size(var,3)*(size(var,4))));
           w_displace=w_displace+mul.*(var(idx+t*size(var,1)*size(var,2)*size(var,3)+2*size(var,1)*size(var,2)*size(var,3)*(size(var,4))));
           % lagrangian (dX_0->t)
           u=grid_coor_ori-floor(grid_coor_ori);
           v=floor(grid_coor_ori)-1;
           idx=v(:,:,:,1)+l+1+(v(:,:,:,2)+m)*size(var_0,1)+(v(:,:,:,3)+n)*size(var_0,1)*size(var_0,2);
           mul=basic_cubic_splines(u(:,:,:,1),l).*basic_cubic_splines(u(:,:,:,2),m).*basic_cubic_splines(u(:,:,:,3),n);
           u_displace_0=u_displace_0+mul.*var_0(idx+t*size(var_0,1)*size(var_0,2)*size(var_0,3)+0);
           v_displace_0=v_displace_0+mul.*var_0(idx+t*size(var_0,1)*size(var_0,2)*size(var_0,3)+1*size(var_0,1)*size(var_0,2)*size(var_0,3)*(reg.GridSize(5)));
           w_displace_0=w_displace_0+mul.*var_0(idx+t*size(var_0,1)*size(var_0,2)*size(var_0,3)+2*size(var_0,1)*size(var_0,2)*size(var_0,3)*(reg.GridSize(5)));       
        end
    end
end
grid_coor_loc=grid_coor+cat(4,u_displace/reg.GridSpacing(1),v_displace/reg.GridSpacing(2),w_displace/reg.GridSpacing(3));
grid_coor_0=grid_coor_ori+cat(4,u_displace_0/reg.GridSpacing(1),v_displace_0/reg.GridSpacing(2),w_displace_0/reg.GridSpacing(3));
grid_coor=(1-ratio)*grid_coor_0+ratio*grid_coor_loc;
coor_colate(:,:,:,:,t+1)=grid_coor;
end
coor_colate=cat(5,grid_coor_ori,coor_colate);


    %% Fourier of coordinates across time
    disp('Fourier Fitting');
    N_plus_1=N+1;%so that the definition of N is consistent with python and or manuscript (N counts from 1 in matlab, but zero in python/manuscript)
    coeff_colate_stor=coor_colate;
    coeff_colate_stor=permute(coeff_colate_stor,[ 1 2 3 5 4]);
    coeff_colate4=coor_colate;
    coeff_colate4=permute(coeff_colate4,[ 1 2 3 5 4]);
    Fourier_sin=zeros(size(coeff_colate4,1),size(coeff_colate4,2),size(coeff_colate4,3),N_plus_1,size(coeff_colate4,5));
    Fourier_cos=zeros(size(coeff_colate4,1),size(coeff_colate4,2),size(coeff_colate4,3),N_plus_1,size(coeff_colate4,5));
    t=0:(reg.GridSize(5));
    Fuhrier=[];

    points=(0:reg.GridSize(5)-1)';
    mat=[];
    for j=0:(N_plus_1-1)
      mat=[mat cos(2*pi*points*j/(reg.GridSize(5)))];
    end
    for j=1:(N_plus_1-1)
      mat=[mat sin(2*pi*points*j/(reg.GridSize(5)))];
    end
    mat=pinv(mat);
        for i=1:size(coeff_colate4,1)
            for j=1:size(coeff_colate4,2)
                for k=1:size(coeff_colate4,3)
           for dir=1: size(coeff_colate4,5)
                 Fourier=mat*[reshape(coeff_colate4(i,j,k,1:reg.GridSize(5),dir),reg.GridSize(5),1);];
                 Fourier_cos(i,j,k,:,dir)=reshape(Fourier(1:N_plus_1),1,1,1,1,N_plus_1);
                 Fourier_sin(i,j,k,:,dir)=reshape([0;Fourier((N_plus_1+1):end)],1,1,1,1,N_plus_1);
           end
                end
            end
        end
    Fuhrier=cat(4,Fourier_cos,Fourier_sin);
    Fuhrier=permute(Fuhrier,[ 1 2 3 5 4]);
    Fuhrier(:,:,:,:,N_plus_1+1)=[];
    %% Multi Level Bspline
    disp('Running MLB');
    % make sure that 2^(levels-1) does not exceed limits-origin
    grid_coor_ori=Fuhrier(:,:,:,:,1); % transforming original grid to the reference grid by changing grid origin to that of 0th fourier terms
    Fuhrier(:,:,:,:,1)=zeros(size(grid_coor_ori)); % followed by removal of the 0th fourier term
    
    n=b_spline_seed;
    n_grid=n.*2.^levels;

%     origin=[floor(min(min(min(min(grid_coor_ori(:,:,:,1)))))) floor(min(min(min(min(grid_coor_ori(:,:,:,2)))))) floor(min(min(min(min(grid_coor_ori(:,:,:,3))))))];
    origin=[0 0 0];
    limits=[ceil(max(max(max(max(grid_coor_ori(:,:,:,1)-origin(1)))))) ceil(max(max(max(max(grid_coor_ori(:,:,:,2)-origin(2)))))) ceil(max(max(max(max(grid_coor_ori(:,:,:,3)-origin(3))))))]+1;
    den=[limits(1)/n_grid(1) limits(2)/n_grid(2) limits(3)/n_grid(3)];
    n_grid=n_grid+3;
    coeff_colate4=zeros(n(1)*2^levels(1)+3,n(2)*2^levels(2)+3,n(3)*2^levels(3)+3,size(Fuhrier,4),3);

    for f=1:size(Fuhrier,5)
        f
    coeff_colate3=zeros(n(1)*2^levels(1)+3,n(2)*2^levels(2)+3,n(3)*2^levels(3)+3,3);

        for dir=1:3

        coeff_colate3(:,:,:,dir)=MBA_single_coeff_3D(grid_coor_ori(:,:,:,1)-origin(1),grid_coor_ori(:,:,:,2)-origin(2),grid_coor_ori(:,:,:,3)-origin(3),Fuhrier(:,:,:,dir,f),n,levels,limits);
        end
    coeff_colate4(:,:,:,f,:)=reshape(coeff_colate3,size(coeff_colate4,1),size(coeff_colate4,2),size(coeff_colate4,3),1,size(coeff_colate4,5));
    end

    disp('writing file.. going to take long');
    coeff_colate4(:,:,:,:,1)=coeff_colate4(:,:,:,:,1)*reg.GridSpacing(1);
    coeff_colate4(:,:,:,:,2)=coeff_colate4(:,:,:,:,2)*reg.GridSpacing(2);
    coeff_colate4(:,:,:,:,3)=coeff_colate4(:,:,:,:,3)*reg.GridSpacing(3);
    save_coeff=reshape(coeff_colate4,size(coeff_colate4,1)*size(coeff_colate4,2)*size(coeff_colate4,3)*size(coeff_colate4,4)*size(coeff_colate4,5),1);
        fileID = fopen(OutputFileName,'w');
        fprintf(fileID,'(GridOrigin %d %d %d %.1f)\n',(origin(1)*reg.GridSpacing(1)+reg.GridOrigin(1)-reg.GridSpacing(1)*den(1)),(origin(2)*reg.GridSpacing(2)+reg.GridOrigin(2)-reg.GridSpacing(2)*den(2)),(origin(3)*reg.GridSpacing(3)+reg.GridOrigin(3)-reg.GridSpacing(3)*den(3)),0);
        fprintf(fileID,'(GridSize %d %d %d %d %d)\n',size(coeff_colate4,1),size(coeff_colate4,2),size(coeff_colate4,3),size(coeff_colate4,4),size(coeff_colate4,5));
        fprintf(fileID,'(GridSpacing %.8d %.8d %.8d %.1f)\n',(reg.GridSpacing(1)*den(1)),(reg.GridSpacing(2)*den(2)),(reg.GridSpacing(3)*den(3)),reg.GridSize(5));
        fprintf(fileID,'%.8d\n',save_coeff);
        fclose(fileID);
    disp('Finally....');
end

