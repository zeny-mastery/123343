

import numpy as np
import os
#import matplotlib
import sys
#sys.path.insert(0, os.path.dirname(os.path.realpath(__file__)))
import medImgProc
import medImgProc.processFunc as pf
import re

import bfmotionsolver

'''
User Variables
'''
fileScale=200. #file size
savePath=r'C:\Users\yaplab2\Desktop\Sheldon method paper data\NE140' #data case directory
bgrid=10.  #ratio of grid size to largest element spacing
bweight=1. #ratio of objective to regualrization weights used for sitk image registration
saveName='Shape11x11x11x9_smooth_gamma_RMS' #file name to be used to save results and partial results
fourierTerms=4 #number of cosine terms (does not include 0th term, sine term is automatically determined)
vtkPath=savePath+'/3DUS/VTK/VTK{0:02d}.vtk'
vtkelementspacing=[0.658114, 0.667832, 0.580462] #pixel to physical coordinate conversion (x,y,z)
finalShape=(11,11,11,fourierTerms*2+1,3) #final shape of bsplineFourier coefficients (x,y,z,f,3), if = None, it is defaulted to the same shape as the first bspline file
 
 
 
'''
initialisation of variables
'''
imregPath=savePath+'/RMSw'+str(bweight)+'b'+str(bgrid)+'/transform'
regfile_general='/t{0:d}to{1:d}_0.txt'
dimension=['z','y','x'] #vtk image array dimension arrangement
'''
Step 1: Image registration 
'''
changeDim={}
for n in range(3):
    changeDim[dimension[n]]=vtkelementspacing[2-n]*fileScale
changeDim['t']=1.
TFimages=[]
for TF in range(100):
    newImg=medImgProc.imread(vtkPath.format(TF),dimension=dimension)
    if type(newImg.data)==type(None):
        break
    else:
        TFimages.append(newImg)
caseImage=medImgProc.stackImage(TFimages,'t')
caseImage.dimlen=changeDim.copy()
caseImage.save(savePath+'/img')
pf.TmapRegister(caseImage,savePath=savePath+'/RMSw'+str(bweight)+'b'+str(bgrid),origin=(0.,0.,0.),bgrid=bgrid,bweight=bweight,rms=True)

'''
Setup - do not comment out
'''																												 
timeList=np.loadtxt(imregPath+'/timeList')										  
timestepNo=len(timeList)
timestep=timeList[1]									  
					
'''
Alternative Step 2 & 3: Forward marching and bspline-Fourier initialization without multi-level bspline
'''
timeMapList=[] # correcponding time map of bspline vectors
fileList=[] # get file path of bspline vectors into lists
for n in range(timestepNo): # input bspline vectors mapping t0 -> tn
    if n!=0:
        timeMapList.append([0,timeList[n]])
        fileList.append(imregPath+regfile_general.format(0,n))
        
for n in range(timestepNo): # input bspline vectors mapping tn-1 -> tn
    if n!=0:
        timeMapList.append([timeList[n-1],timeList[n]])
        fileList.append(imregPath+regfile_general.format(n-1,n))

solver=bfmotionsolver.BFSolver()

solver.addBsplineFile(fileList,timeMapList=timeMapList,fileScale=fileScale)

solver.initialize(shape=finalShape,period=timestep*timestepNo,fourierTerms=fourierTerms) # initialise solver with shape, setting the period and number of fourier terms
solver.estimateInitialwithRefTime(timestepNo-1,OrderedBsplinesList2=range(timestepNo-1,2*(timestepNo-1)),spacingDivision=2.,gap=0)
solver.bsFourier.writeCoef(savePath+'/'+saveName+'_fft.txt') #save coefficients


'''
Step 4: Batch correction
'''
timeMapList=[] # correcponding time map of bspline vectors
fileList=[] # get file path of bspline vectors into lists
for n in range(timestepNo): # input bspline vectors mapping tn-1 -> tn
    if n!=0:
        timeMapList.append([timeList[n-1],timeList[n]])
        fileList.append(imregPath+regfile_general.format(n-1,n))

timeMapList.append([0,timeList[-1]]) # include bspline vectors mapping t0 -> tend
fileList.append(imregPath+regfile_general.format(0,(timestepNo-1)))

solver=bfmotionsolver.BFSolver()
solver.addBsplineFile(fileList,timeMapList=timeMapList,fileScale=fileScale) #add bspline to solver
solver.bsFourier=bfmotionsolver.BsplineFourier(savePath+'/'+saveName+'_fft.txt') # load initialised coefficients

#Step 4.2 additional vector
#solver.addBsplineFile(imregPath+regfile_general.format(6,29),timeMapList=[timeList[6],timeList[29]],weightList=10.,fileScale=fileScale)

solver.initialize(shape=finalShape,spacing=solver.bsFourier.spacing,origin=solver.bsFourier.origin,spacingDivision=2.0,gap=1) # initialise solver with shape and sampling points 2^3 (double along each dimension) more than b-spline grid size

solver.solve(maxIteration=1000,convergence=0.5,reportevery=60,tempSave=savePath+'/'+saveName+'_f'+str(fourierTerms)+'_samplingResults_temp.txt') #Batch correction
solver.bsFourier.writeCoef(savePath+'/'+saveName+'_f'+str(fourierTerms)+'.txt') #save coefficients
solver.writeSamplingResults(savePath+'/'+saveName+'_f'+str(fourierTerms)+'_samplingResults.txt') #save sampling results

