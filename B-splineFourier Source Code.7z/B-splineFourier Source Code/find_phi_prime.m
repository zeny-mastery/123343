function [ phi_prime ] = find_phi_prime( prev_coeff )
%FIND_PHI_PRIME Summary of this function goes here
%   Detailed explanation goes here
prev_coeff=reshape(prev_coeff,numel(prev_coeff),1);
phi_prime=zeros(length(prev_coeff)*2-3,1);
i=2:(length(prev_coeff)-1);
phi_prime(2*i-2)=(6*prev_coeff(i)+prev_coeff(i+1)+prev_coeff(i-1))/8;
phi_prime(2*i-1)=(prev_coeff(i)+prev_coeff(i+1))/2;
phi_prime(1)=(prev_coeff(1)+prev_coeff(2))/2;


end

