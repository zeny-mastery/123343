function [reg] = Compile_registrations(TransformFolder,dt,reg_scale)
%Reading the registration files and return reg
%   Definition: t->t+dt refers to registration from time t (deformed image)
%   to t+dt (fixed image).
%
%   Input:
%   -TransformFolder is the file location of the registration results (where
%   t0to1_0.txt is stored)
%   -dt is the neighbourhood relationship, registration coefficients from
%   t->t+dt will be read. However, when dt=0, it registration from 0->t
%   would be read instead.
%
%   Output are the structure registration parameters (reg):
% 	-reg.Coeffs stores the pairwise b-spline registration coefficients
%   -reg.GridOrigin b-spline grid origin in physical coordinate
%   -reg.GridSpacing b-spline grid spacing 
%   -reg.GridSize stores the b-spline shape (x,y,z,3,t)
%   -reg.ImgSpacing image pixel resolution in physical coordinate
%   -reg.ImgSize number of Image Pixels in x and y (col and row)
% 	-reg.t stores the value of t
% 	-reg.dt stores the value of dt for easy indexing
%   
%% read transform parameters
reg=struct('GridOrigin',[],'GridSize',[],'GridSpacing',[],'ImgSize',[],'ImgSpacing',[],'Coeffs',[],'t',[],'dt',[]);
TimePnts=dlmread([TransformFolder '/timelist']);
TimePnts=length(TimePnts);
FileName=sprintf('t%dto%d_0.txt',mod(0+TimePnts,TimePnts),mod((1+dt(1)+TimePnts),TimePnts));
fid = fopen([TransformFolder '/' FileName],'rt');
text=[];
for j=1:10
text=fgets(fid);
end
text(1:12)=[];
text(end-1:end)=[];
reg.GridOrigin=str2num(text)/reg_scale;

text=fgets(fid);
text(1:10)=[];
text(end-1:end)=[];
reg.GridSize=str2num(text);
reg.GridSize=[reg.GridSize 3 TimePnts];

text=fgets(fid);
text(1:13)=[];
text(end-1:end)=[];
reg.GridSpacing=str2num(text)/reg_scale;

for j=1:12
text=fgets(fid);
end
text(1:6)=[];
text(end-1:end)=[];
reg.ImgSize=str2num(text);

text=fgets(fid);
text(1:9)=[];
text(end-1:end)=[];
reg.ImgSpacing=str2num(text)/reg_scale;


fclose(fid);

reg.Coeffs=zeros(reg.GridSize(1),reg.GridSize(2),reg.GridSize(3),reg.GridSize(4),TimePnts*length(dt));
reg.t=zeros(TimePnts*length(dt),1);
reg.dt=zeros(TimePnts*length(dt),1);
%% reading the b-spline coefficients
linenum=27;
counter=0;
for (k=1:length(dt))
for i=0:TimePnts-1;
    flip=1;
    reg.dt(counter+1)=dt(k);
    if dt(k)~=0
        
        FileName=sprintf('t%dto%d_0.txt',mod(i+TimePnts,TimePnts),mod((i+dt(k)+TimePnts),TimePnts));
        reg.t(counter+1)=mod(i+TimePnts,TimePnts);
        if(mod((i+dt(k)+TimePnts),TimePnts)==0 && ~isfile([TransformFolder '/' FileName])) %% if P-1 to 0 registeration is not available, we add negatives to the registration result of 0 to P-1 (this is not a proper way to do an inverse, further update should address this)
            disp('flipping');
            flip=-1;
            FileName=sprintf('t%dto%d_0.txt',mod((i+dt(k)+TimePnts),TimePnts),mod(i+TimePnts,TimePnts));
        end
    else
        FileName=sprintf('t%dto%d_0.txt',0,mod((i+1+dt(k)+TimePnts),TimePnts));
        reg.t(counter+1)=0;
        if i==(TimePnts-1)
            counter=counter+1;
            break;
        end
    end
fid = fopen([TransformFolder '/' FileName],'rt');
disp(sprintf('reading %s',FileName));
text=[];
for j=1:linenum
text=fgets(fid);
end
fclose(fid);
text(1:21)=[];
text(end-2:end)=[];
number=str2num(text);
number=flip*number;
counter=counter+1;
reg.Coeffs(:,:,:,:,counter)=reshape(number,reg.GridSize(1),reg.GridSize(2),reg.GridSize(3),reg.GridSize(4))/reg_scale;
end
end

% end
end

