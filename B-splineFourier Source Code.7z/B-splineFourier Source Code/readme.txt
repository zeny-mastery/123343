Bspline of Fourier modelling to fit pairwise registration displacement fields by imposing cyclic constraint of Fourier across time and smoothness of b-spline grids across space.

As stated in the manuscript there are a total of 5 steps, and each steps would be provided with a *step_name*_main files, that calls other functions/modules to perform that particular step.

Some of codes are written in Matlab and some are written in Python. Two python modules were included: medImgProc (for image registration) and bfmotionsolver (for Bspline fourier optimisation)

Python Dependencies:
simpleElastix (install via instructions on https://simpleelastix.github.io/)
autoD (run: pip install autoD)
numpy (run: pip install numpy)
re 	(run: pip install re)
scipy (run: pip install scipy)
matplotlib (run: pip install matplotlib)
imageio (run: pip install imageio)

Matlab dependencies:
stlread by Eric Johnson download from:https://www.mathworks.com/matlabcentral/fileexchange/22409-stl-file-reader?focused=5193625&tab=function
stlwrite by Sven Holcombe download from:https://www.mathworks.com/matlabcentral/fileexchange/20922-stlwrite-write-ascii-or-binary-stl-files
Matlab parallel computing toolbox

Step1: Pairwise image registration
Run in Python Pairwise_main.py, image registration were done with simpleElastix module.

Step2 and 3: Forward Marching and Initialisation
Run in Matlab Initialisation_main.m.
Alternatively, Initialisation_main.py can be used, although it is not what were used in the manuscript.

Step4: Batch Correction
Run in Python Batch_correction_main.py.

Step5: Lagrangian tracking
Run in Matlab Lagrangian_tracking_main.m.

Alternative step1:4
Run in Python All.py

We aim to write all of the processing in Python, but the result might differ from Matlab runs.