function [ coeff ] = BA_3D(x,y,z,u,n,limits)
%REGRID_ Summaru of this function goes here
%   Detailed explanation goes here
delta=zeros(n(1)+3,n(2)+3,n(3)+3);
omega=zeros(n(1)+3,n(2)+3,n(3)+3);
den=[limits(1)/n(1) limits(2)/n(2) limits(3)/n(3)];
coor=cat(4,x,y,z);
den=repmat(reshape(den,1,1,1,3),size(coor,1),size(coor,2),size(coor,3),1);
i=floor(coor./den)-1;
s=(coor./den-floor(coor./den));
    wa=zeros(size(x,1),size(x,2),size(x,3));
    wks=zeros(size(x,1),size(x,2),size(x,3),4,4,4);
    for c=0:3
        for b=0:3
            for a=0:3
       wks(:,:,:,a+1,b+1,c+1)=basic_cubic_splines(s(:,:,:,1),a).*basic_cubic_splines(s(:,:,:,2),b).*basic_cubic_splines(s(:,:,:,3),c);
       wa=wa+ wks(:,:,:,a+1,b+1,c+1).^2;
            end
        end
    end
    for m=0:3
        for l=0:3
            for k=0:3
                idx=(i(:,:,:,1)+k+2)+ (i(:,:,:,2)+l+2-1)*size(delta,1)+ (i(:,:,:,3)+m+2-1)*size(delta,2)*size(delta,1);
                pk=wks(:,:,:,k+1,l+1,m+1).*u./wa;
                delta(idx)= delta(idx)+wks(:,:,:,k+1,l+1,m+1).^2.*pk;
                omega(idx)=omega(idx)+wks(:,:,:,k+1,l+1,m+1).^2;
            end
        end
    end

coeff=delta./omega;
loc=find(omega==0);
coeff(loc)=0;
end

