%% initialisation main code
WorkDir='H:\B-splineFourier data\Zebrafish_data\Zebrafish 1\result\bsf';
TransformFolder=[WorkDir '\' 'pairwise\transform'];
dt=[0 1];
reg_scale=20.; %file scaling property due to the limitation of elastix which stores values not in scientific notation (up to 6 decimal place)
               %to prevent trucation error, all values were scaled by fixed
               %number for fetal data:1000, chick data: 200, zebrafish 20
reg=Compile_registrations(TransformFolder,dt,reg_scale);

%% run initialisation
N=4;
b_spline_seed=[1 1 1];% number of control points in the first levels for each dimension
levels=[4 4 4]; % bspline levels used
n_grid=b_spline_seed.*2.^levels+3; % total number of bspline control points as given by MLB, it doubles the control point at every level
reg_scale=1.; %scale returned to 1 as it is already been accounted for
OutputFileName=[WorkDir '\' 'Shape' num2str(n_grid(1)) 'x' num2str(n_grid(2)) 'x' num2str(n_grid(3)) 'x' num2str(N*2+1) '_init' '.txt'];
run_initialisation(reg,TransformFolder,N,b_spline_seed,levels,OutputFileName);