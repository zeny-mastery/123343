import numpy as np
import os
#import matplotlib
import sys
#sys.path.insert(0, os.path.dirname(os.path.realpath(__file__)))
import medImgProc
import medImgProc.processFunc as pf
import re

import bfmotionsolver

'''
User Variables
'''
fileScale=200. #file size
savePath=r'C:\Users\yaplab2\Desktop\Sheldon method paper data\NE140' #data case directory
bgrid=10.  #ratio of grid size to largest element spacing
bweight=1. #ratio of objective to regualrization weights used for sitk image registration
saveName='Shape11x11x11x9_smooth_gamma_RMS' #file name to be used to save results and partial results
fourierTerms=4 #number of cosine terms (does not include 0th term, sine term is automatically determined)
vtkPath=savePath+'/3DUS/VTK/VTK{0:02d}.vtk'
vtkelementspacing=[0.658114, 0.667832, 0.580462] #pixel to physical coordinate conversion (x,y,z)
finalShape=(11,11,11,fourierTerms*2+1,3) #final shape of bsplineFourier coefficients (x,y,z,f,3), if = None, it is defaulted to the same shape as the first bspline file
 
imregPath=savePath+'/RMSw'+str(bweight)+'b'+str(bgrid)+'/transform'
timeList=np.loadtxt(imregPath+'/timeList')
regfile_general='/t{0:d}to{1:d}_0.txt'
timestepNo=len(timeList)
timestep=timeList[1]
dimension=['z','y','x']

'''
Alternative Step 2 & 3: Forward marching and bspline-Fourier initialization
'''
timeMapList=[] # correcponding time map of bspline vectors
fileList=[] # get file path of bspline vectors into lists
for n in range(timestepNo): # input bspline vectors mapping t0 -> tn
    if n!=0:
        timeMapList.append([0,timeList[n]])
        fileList.append(imregPath+regfile_general.format(0,n))
        
for n in range(timestepNo): # input bspline vectors mapping tn-1 -> tn
    if n!=0:
        timeMapList.append([timeList[n-1],timeList[n]])
        fileList.append(imregPath+regfile_general.format(n-1,n))

solver=bfmotionsolver.BFSolver()

solver.addBsplineFile(fileList,timeMapList=timeMapList,fileScale=fileScale)

solver.initialize(shape=finalShape,period=timestep*timestepNo,fourierTerms=fourierTerms) # initialise solver with shape, setting the period and number of fourier terms
solver.estimateInitialwithRefTime(timestepNo-1,OrderedBsplinesList2=range(timestepNo-1,2*(timestepNo-1)),spacingDivision=2.,gap=0)
solver.bsFourier.writeCoef(savePath+'/'+saveName+'_fft.txt') #save coefficients
